# References – Harvard Style

Statistics South Africa. 2026. *South Africa's Youth and the Labour Market in Q1 2026*. Pretoria: Statistics South Africa. Available at: https://www.statssa.gov.za/?p=19526 [Accessed 14 August 2026].

Statistics South Africa. 2026. *Quarterly Labour Force Survey, Quarter 1: 2026*. Pretoria: Statistics South Africa. Available at: https://www.statssa.gov.za/publications/P0211/Presentation%20QLFS%20Q1%202026.pdf [Accessed 14 August 2026].

Statistics South Africa. 2025. *Marginalised Groups Series VII: The Social Profile of the Youth, 2014–2024*. Pretoria: Statistics South Africa. Available at: https://www.statssa.gov.za/publications/Report-03-19-09/Report-03-19-09.pdf [Accessed 14 August 2026].

Department of Higher Education and Training. 2022. *Implementation Programme for the National Digital and Future Skills Strategy of South Africa – Decent Jobs for Youth*. Pretoria: Government of South Africa. Available at: https://www.gov.za/documents/other/implementation-programme-national-digital-and-future-skills-strategy-south-africa [Accessed 14 August 2026].

Images: Any third-party images added during later development must be individually referenced with creator, source and licence information.

## SEO and publishing references (Part 2)

Google. 2026. *Google Search Essentials*. Available at: https://developers.google.com/search/docs/essentials [Accessed 31 October 2026].

Google. 2026. *Spam policies for Google web search*. Available at: https://developers.google.com/search/docs/essentials/spam-policies [Accessed 31 October 2026].

Google. 2026. *SEO Starter Guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide [Accessed 31 October 2026].

Google. 2026. *Introduction to robots.txt*. Available at: https://developers.google.com/search/docs/crawling-indexing/robots/intro [Accessed 31 October 2026].

Sitemaps.org. 2016. *Sitemaps XML format*. Available at: https://www.sitemaps.org/protocol.html [Accessed 31 October 2026].

GitHub. 2026. *Creating a GitHub Pages site*. Available at: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site [Accessed 31 October 2026].
