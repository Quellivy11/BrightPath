/* =========================================================
   BrightPath Youth Development Foundation – site scripts
   Loaded with "defer" on every page, so the DOM is ready.
   ========================================================= */

const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* =========================
   1. MOBILE NAVIGATION
   ========================= */

function initMobileNav() {
    const toggle = document.querySelector(".menu-toggle");
    const nav = document.getElementById("main-nav");
    if (!toggle || !nav) return;

    function setOpen(open) {
        nav.classList.toggle("open", open);
        toggle.setAttribute("aria-expanded", String(open));
        toggle.textContent = open ? "Close" : "Menu";
    }

    toggle.addEventListener("click", function () {
        setOpen(!nav.classList.contains("open"));
    });

    // Close the menu after choosing a link, pressing Escape or clicking outside it
    nav.addEventListener("click", function (event) {
        if (event.target.closest("a")) setOpen(false);
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape" && nav.classList.contains("open")) {
            setOpen(false);
            toggle.focus();
        }
    });

    document.addEventListener("click", function (event) {
        if (!nav.contains(event.target) && !toggle.contains(event.target)) setOpen(false);
    });
}

/* =========================
   2. FORM VALIDATION
   Works for any <form data-validate>. Client-side checks only
   improve the user experience; nothing is sent or stored.
   ========================= */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function getFieldError(field) {
    const value = field.type === "checkbox" ? field.checked : field.value.trim();
    const label = document.querySelector('label[for="' + field.id + '"]');
    const name = label ? label.textContent.replace("*", "").trim() : "This field";

    if (field.type === "checkbox") {
        return value ? "" : "Please tick this box to continue.";
    }
    if (field.required && !value) {
        return field.tagName === "SELECT" ? "Please choose an option." : name + " is required.";
    }
    if (field.type === "email" && !EMAIL_PATTERN.test(value)) {
        return "Please enter a valid email address, e.g. name@example.com.";
    }
    if (field.minLength > 0 && value.length < field.minLength) {
        return name + " must be at least " + field.minLength + " characters.";
    }
    return "";
}

function showFieldError(field, message) {
    const error = document.getElementById(field.id + "-error");
    error.textContent = message;
    field.classList.toggle("invalid", Boolean(message));
    field.setAttribute("aria-invalid", String(Boolean(message)));
}

function addCharacterCounter(textarea) {
    if (!textarea.maxLength || textarea.maxLength < 0) return;
    const counter = document.createElement("p");
    counter.className = "char-counter";
    counter.setAttribute("aria-live", "polite");
    textarea.insertAdjacentElement("afterend", counter);

    function update() {
        const remaining = textarea.maxLength - textarea.value.length;
        counter.textContent = remaining + " characters remaining";
        counter.classList.toggle("near-limit", remaining <= 50);
    }
    textarea.addEventListener("input", update);
    textarea.form.addEventListener("reset", function () { setTimeout(update); });
    update();
}

function initFormValidation(form) {
    const fields = Array.from(form.querySelectorAll("input, select, textarea"));
    const status = form.querySelector(".form-message");

    fields.forEach(function (field) {
        // Create an error message slot under each field and link it for screen readers
        const error = document.createElement("p");
        error.className = "field-error";
        error.id = field.id + "-error";
        const anchor = field.type === "checkbox" ? field.closest("label") : field;
        anchor.insertAdjacentElement("afterend", error);
        field.setAttribute("aria-describedby", error.id);

        if (field.tagName === "TEXTAREA") addCharacterCounter(field);

        // Validate when the user leaves a field, then live while they fix it
        field.addEventListener("blur", function () {
            showFieldError(field, getFieldError(field));
        });
        field.addEventListener(field.type === "checkbox" || field.tagName === "SELECT" ? "change" : "input", function () {
            if (field.classList.contains("invalid")) showFieldError(field, getFieldError(field));
        });
    });

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        let firstInvalid = null;

        fields.forEach(function (field) {
            const message = getFieldError(field);
            showFieldError(field, message);
            if (message && !firstInvalid) firstInvalid = field;
        });

        if (firstInvalid) {
            status.textContent = "Please correct the highlighted fields.";
            status.className = "form-message error";
            firstInvalid.focus();
            return;
        }

        const firstName = form.querySelector('input[type="text"]').value.trim().split(" ")[0];
        status.textContent = "Thank you, " + firstName + "! Your message passed validation. (Demo only: no data was sent.)";
        status.className = "form-message success";
        form.reset();
    });
}

/* =========================
   3. ENQUIRY FORM PREFILL
   Links such as enquiry.html?type=programme&programme=Career%20Ready
   pre-select the enquiry type and start the message for the visitor.
   ========================= */

function initEnquiryPrefill() {
    const typeSelect = document.getElementById("type");
    const message = document.getElementById("message");
    if (!typeSelect || !message) return;

    const params = new URLSearchParams(window.location.search);
    const type = params.get("type");
    const programme = params.get("programme");

    if (type && typeSelect.querySelector('option[value="' + CSS.escape(type) + '"]')) {
        typeSelect.value = type;
    }
    if (programme && !message.value) {
        message.value = "I would like to find out more about joining the " + programme + " programme.";
        message.dispatchEvent(new Event("input"));
    }
}

/* =========================
   4. ANIMATED STATISTIC (home page)
   Counts up from 0 the first time the number scrolls into view.
   ========================= */

function initStatCounters() {
    const counters = document.querySelectorAll("[data-count-to]");
    if (!counters.length || prefersReducedMotion || !("IntersectionObserver" in window)) return;

    function animate(el) {
        const target = parseFloat(el.dataset.countTo);
        const decimals = parseInt(el.dataset.decimals || "0", 10);
        const suffix = el.dataset.suffix || "";
        const duration = 1400;
        const start = performance.now();

        function frame(now) {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = (target * eased).toFixed(decimals) + suffix;
            if (progress < 1) requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                animate(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.6 });

    counters.forEach(function (el) { observer.observe(el); });
}

/* =========================
   5. "OPEN NOW" STATUS (contact page)
   Uses South African time so the badge is correct for any visitor.
   ========================= */

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function getJohannesburgTime() {
    const parts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Africa/Johannesburg",
        weekday: "short",
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23"
    }).formatToParts(new Date());

    const get = function (type) { return parts.find(function (p) { return p.type === type; }).value; };
    const day = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(get("weekday"));
    return { day: day, minutes: parseInt(get("hour"), 10) * 60 + parseInt(get("minute"), 10) };
}

function toMinutes(time) {
    const [h, m] = time.split(":").map(Number);
    return h * 60 + m;
}

function updateOpenStatus() {
    const now = getJohannesburgTime();

    document.querySelectorAll(".open-status").forEach(function (el) {
        const [firstDay, lastDay] = el.dataset.days.split("-").map(Number);
        const open = toMinutes(el.dataset.open);
        const close = toMinutes(el.dataset.close);
        const isOpenDay = function (d) { return d >= firstDay && d <= lastDay; };

        if (isOpenDay(now.day) && now.minutes >= open && now.minutes < close) {
            el.textContent = "Open now · closes at " + el.dataset.close;
            el.className = "open-status is-open";
            return;
        }

        // Work out when the location next opens
        let label;
        if (isOpenDay(now.day) && now.minutes < open) {
            label = "today";
        } else {
            let next = (now.day + 1) % 7;
            while (!isOpenDay(next)) next = (next + 1) % 7;
            label = next === (now.day + 1) % 7 ? "tomorrow" : DAY_NAMES[next];
        }
        el.textContent = "Closed now · opens " + label + " at " + el.dataset.open;
        el.className = "open-status is-closed";
    });
}

function initOpenStatus() {
    if (!document.querySelector(".open-status")) return;
    updateOpenStatus();
    setInterval(updateOpenStatus, 60000);
}

/* =========================
   6. FOOTER YEAR
   ========================= */

function initFooterYear() {
    document.querySelectorAll("[data-year]").forEach(function (el) {
        el.textContent = new Date().getFullYear();
    });
}

/* =========================
   START
   ========================= */

initMobileNav();
document.querySelectorAll("form[data-validate]").forEach(initFormValidation);
initEnquiryPrefill();
initStatCounters();
initOpenStatus();
initFooterYear();
