# Off-Page SEO Plan – BrightPath

This is my response to the "Student activity" in the *SEO and Publishing* guide. BrightPath is a fictional organisation, so everything below is a **plan** describing what I would do if it were real. I have not contacted anyone, created any business profiles or posted anything, and none of this guarantees backlinks or search placement.

## 1. Three plausible local organisations that might link to the site

| Organisation (plausible) | Why the link would be useful to *their* audience | Page I would ask them to link to |
|---|---|---|
| A university or TVET college career-services office in Polokwane | Their students and recent graduates are looking for CV, interview and job-search support | `services.html#career-ready` |
| A Seshego community library or youth centre notice board / website | Their visitors include school leavers who want free digital-skills help close to home | `services.html#digital-foundations` |
| A Limpopo volunteer network or local business association | Their members look for volunteering and corporate social investment opportunities | `enquiry.html` |

## 2. Polite outreach message (draft)

> Subject: Free youth digital-skills and career sessions in Polokwane and Seshego
>
> Good day,
>
> My name is [Name] and I coordinate programmes at BrightPath Youth Development Foundation. We run practical digital-skills, CV and interview-preparation sessions for young people at our Polokwane CBD and Seshego locations.
>
> I thought this might be useful to the students and young people you support. Our programme page explains what each session covers and how to enquire: [live URL]/services.html
>
> If you feel it would help your audience, you are welcome to share the page or list it with your other youth resources. There is no obligation at all, and I'd be happy to answer any questions.
>
> Kind regards,
> [Name], BrightPath Youth Development Foundation
> 015 555 0142 | hello@brightpathyouth.org.za

## 3. One social post that points people to a relevant page

> 📣 Leaving school or job hunting? Our free **Career Ready** sessions in Polokwane cover CVs, cover letters and interview practice. See what's included and enquire here 👉 [live URL]/services.html#career-ready

This links straight to the programme section instead of the home page, so people land on the information they need.

## 4. Things I deliberately did not do

- I did not buy links, join link-exchange schemes or use automated link-building services, because these count as link spam.
- I did not create a Google Business Profile, because BrightPath is fictional and the guide says a classroom organisation should not pretend to be a real business.
- I did not add fake reviews or testimonials to the website.
- I did not add structured data (JSON-LD) describing BrightPath as a real organisation, for the same reason.

## 5. Keeping local details consistent

If BrightPath were real, the name, addresses, phone numbers, opening hours and website address would need to match everywhere it is listed. On the website itself, I made sure these details are identical in the footer and on the Contact page.
